import React from 'react'
import ReactDOM from 'react-dom/client'
import WorkLinkHub from './WorkLinkHub'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <WorkLinkHub />
  </React.StrictMode>
)